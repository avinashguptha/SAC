<?php
session_start();
if (isset($_SESSION["user"])) {
    header("Location: vote.html");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login for SAC</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="background-image"></div>
    <div style="text-align: left;">
        <a href="../../index.html" class="btn btn-primary" role="button">Back</a>
    </div>

    <div class="container">
        <?php
        if (isset($_POST["login"])) {
            $regd_no = $_POST["regd_no"];
            $password = $_POST["password"];

            require_once "database_sac.php";
            $sql = "SELECT * FROM sac_mem WHERE regd_no = '$regd_no'";
            $result = mysqli_query($conn, $sql);
            $user = mysqli_fetch_array($result, MYSQLI_ASSOC);

            if ($user) {  // Check if regd_no exists in database
                if ($password === "Sac@123") { // Check for fixed password
                    session_start();
                    $_SESSION["user"] = "yes";
                    header("Location: vote.html");
                    die();
                } else {
                    echo "<div class='alert alert-danger'>Invalid password</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Regd Number does not match</div>";
            }
        }
        ?>
        <div class="container4">
            <h4>Login for SAC</h4>
        </div>

        <form action="sac_mem_login.php" method="post">
            <div class="form-group">
                <input type="regd_no" placeholder="Enter Regd Number:" name="regd_no" class="form-control">
            </div>
            <div class="form-group">
                <input type="password" placeholder="Enter Password:" name="password" class="form-control">
            </div>
            <div class="form-btn">
                <input type="submit" value="Login" name="login" class="btn btn-primary">
            </div>
        </form>
    </div>
</body>

</html>