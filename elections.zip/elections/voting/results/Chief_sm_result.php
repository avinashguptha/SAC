<?php
// Require the database connection file
require_once "database_res.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the selected_name is set
    if (isset($_POST['selected_name'])) {
        // Get the selected name from the form
        $selectedName = $_POST['selected_name'];

        // Insert the selected name into the sec_music_vote table
        $insertSql = "INSERT INTO chief_sm_vote (selected_name) VALUES ('$selectedName')";
        if ($conn->query($insertSql) === TRUE) {
            echo "Vote submitted successfully.";
        } else {
            echo "Error: " . $insertSql . "<br>" . $conn->error;
        }
    } else {
        echo "Please select a name before submitting the vote.";
    }
} else {
    echo "Invalid request.";
}

// Close connection
$conn->close();
