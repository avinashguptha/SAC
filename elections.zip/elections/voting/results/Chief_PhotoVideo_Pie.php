<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pie Chart - Voting Results</title>
    <!-- Include Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

    <?php
    // Include the database connection file
    require_once "database_res.php";

    // SQL query to retrieve names from sec_music_vote table
    $sql = "SELECT selected_name FROM chief_photovideo_vote";
    $result = $conn->query($sql);

    // Check if there are results
    if ($result->num_rows > 0) {
        // Initialize an array to store names and their counts
        $namesCount = [];

        // Count the occurrences of each name
        while ($row = $result->fetch_assoc()) {
            $name = $row['selected_name'];

            if (isset($namesCount[$name])) {
                $namesCount[$name]++;
            } else {
                $namesCount[$name] = 1;
            }
        }

        // Convert namesCount array into JSON for use in JavaScript
        $namesCountJSON = json_encode($namesCount);

        // Close the database connection
        $conn->close();
    ?>

        <!-- Create a smaller canvas element for the pie chart -->
        <canvas id="myPieChart" width="300" height="300"></canvas>

        <script>
            // Retrieve names and counts from PHP and convert to JavaScript variables
            var namesCount = <?php echo $namesCountJSON; ?>;

            // Get the canvas element
            var ctx = document.getElementById('myPieChart').getContext('2d');

            // Create an array for chart data
            var data = {
                labels: Object.keys(namesCount),
                datasets: [{
                    data: Object.values(namesCount),
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.8)',
                        'rgba(54, 162, 235, 0.8)',
                        'rgba(255, 206, 86, 0.8)',
                        'rgba(75, 192, 192, 0.8)',
                        'rgba(153, 102, 255, 0.8)',
                        'rgba(255, 159, 64, 0.8)'
                    ]
                }]
            };

            // Create a pie chart with options
            var options = {
                responsive: true,
                maintainAspectRatio: false
            };

            var myPieChart = new Chart(ctx, {
                type: 'pie',
                data: data,
                options: options
            });
        </script>
    <?php
    } else {
        echo "No data available to generate the pie chart.";
    }
    ?>

</body>

</html>