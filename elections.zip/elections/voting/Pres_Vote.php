<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>President Nominees Names List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .background-image {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('images/Vfstr.jpg');
            background-size: cover;
            opacity: 0.15;
            pointer-events: none;
            z-index: -1;
        }

        input[type="submit"] {
            margin-top: 20px;
            padding: 10px;
            background-color: #4caf50;
            color: white;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="background-image"></div>

    <form action="results/Pres_result.php" method="post">
        <?php
        // Require the database connection file
        require_once "database_nom.php";

        // SQL query to retrieve names
        $sql = "SELECT name FROM pres_sac";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Vote for the President of SAC</th></tr>";

            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td><label><input type='radio' name='selected_name' value='" . $row["name"] . "'>" . $row["name"] . "</label></td></tr>";
            }

            echo "</table>";

            // Add submit button
            echo "<input type='submit' value='Submit Vote'>";
        } else {
            echo "0 results";
        }

        // Close connection
        $conn->close();
        ?>
    </form>

</body>

</html>