<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nomination Form for Chief Coordinator of MUSIC CLUB</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="background-image"></div>
    <div class="container_nom">
        <?php
        if (isset($_POST["submit"])) {
            $name = $_POST["name"];
            $regd_no = $_POST["regd_no"];
            $department = $_POST["department"];
            $year = $_POST["year"];
            $sec = $_POST["sec"];
            $phone = $_POST["phone"];
            $mail = $_POST["mail"];
            $previous_contribution = $_POST["previous_contribution"];
            $rating = $_POST["rating"];
            $errors = array();

            if (empty($name) || empty($regd_no) || empty($department) || empty($year) || empty($sec) || empty($phone) || empty($mail) || empty($previous_contribution) || empty($rating)) {
                array_push($errors, "All fields are required");
            }
            if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                array_push($errors, "Email is not valid");
            }

            require_once "database_nom.php";

            // Get the image name
            $imageName = $_FILES["image_name"]["name"];

            $sql = "INSERT INTO chief_tech (image_name, name, regd_no, department, year, sec, phone, mail, previous_contribution, rating) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_stmt_init($conn);

            if (mysqli_stmt_prepare($stmt, $sql)) {
                mysqli_stmt_bind_param($stmt, "ssssisisss", $imageName, $name, $regd_no, $department, $year, $sec, $phone, $mail, $previous_contribution, $rating);
                mysqli_stmt_execute($stmt);
                echo "<div class='alert alert-success'>Your Nomination is Registered successfully.</div>";
            } else {
                die("Something went wrong!!!");
            }
        }
        ?>
        <div style="text-align: left;">
            <a href="../../index.html" class="btn btn-primary" role="button">Back</a>
        </div>

        <div class="nomination-form">
            <h5 class="custom-heading">
                <center>Nomination For Chief Coordinator of TECHNICAL DESIGN CLUB</center>
            </h5>
            <p style="color: red; text-align: center;"><strong>(2023 - 2024)</strong></p>
            <form action="Chief_Tech_Nominate.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
                <label for="image">Upload Passport Size Image:</label>
                <input type="file" id="image" name="image_name" accept=".jpg, .jpeg, .png" value="" required>
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
                <label for="regd no">Register Number:</label>
                <input type="text" id="regd no" name="regd_no" required>
                <label for="dept">Department:</label>
                <select id="department" name="department" required>
                    <option>SELECT YOUR DEPARTMENT HERE!</option>
                    <option>Advanced Computer Science and Engineering</option>
                    <option>Agri. & Horti. Sciences</option>
                    <option>Applied Engineering</option>
                    <option>Biotechnology</option>
                    <option>Biomedical Engineering</option>
                    <option>Chemical Engineering</option>
                    <option>Civil Engineering</option>
                    <option>Computer Science and Engineering</option>
                    <option>Department of Chemistry</option>
                    <option>Department of Physics</option>
                    <option>Department of Mathematics</option>
                    <option>Department of English & Other Indian and Foreign Languages</option>
                    <option>Department of Social Sciences & Humanities</option>
                    <option>Diploma: ECE CSE</option>
                    <option>Electronics And Communication Engineering</option>
                    <option>Electrical And Electronics Engineering</option>
                    <option>Food Technology</option>
                    <option>Information Technology</option>
                    <option>Institute Of Law</option>
                    <option>Mechanical Engineering</option>
                    <option>Management Studies</option>
                    <option>Pharmaceutical Sciences</option>
                    <option>Robotic & Automation Engineering</option>
                    <option>Sciences & Humanities</option>
                    <option>Textile Technology</option>
                    <option>Distance & Online Education</option>
                    <option>Civil Services</option>
                </select>
                <label for="name">Year:</label>
                <input type="text" id="name" name="year" required>
                <label for="name">Section:</label>
                <input type="text" id="name" name="sec" required>
                <label for="phone">Phone No:</label>
                <input type="number" id="phone" name="phone" required>
                <label for="mail">Gmail:</label>
                <input type="text" id="mail" name="mail" required>

                <label for="previous-contributions">Previous Contributions for SAC:</label>
                <textarea id="previous-contributions" name="previous_contribution" required></textarea>
                <label for="rating">Rate SAC out of 10:</label>
                <select id="rating" name="rating" required>
                    <option value="None">Rate SAC</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                </select>
                <br></br>
                <div class="form-btn">
                    <input type="submit" class="btn btn-primary" value="Register" name="submit">
                </div>
            </form>
        </div>
</body>

</html>