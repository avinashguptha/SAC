<?php
session_start();

if (isset($_POST['submit'])) {
    $email = $_POST['email'];

    // Generate OTP
    $otp = rand(100000, 999999);

    // Send OTP to email
    $subject = "Voting OTP";
    $message = "Your OTP for voting is: " . $otp;

    // Configure SMTP settings
    ini_set('SMTP', 'smtp.gmail.com');
    ini_set('smtp_port', 587);
    ini_set('sendmail_from', 'youremail@gmail.com');
    ini_set('smtp_auth', 'true');
    ini_set('smtp_secure', 'tls');

    // Enable STARTTLS
    ini_set('smtp_starttls', 'true');

    // Send the email using the configured SMTP settings
    mail($email, $subject, $message);

    // Store OTP in session
    $_SESSION['otp'] = $otp;

    // Display message
    echo "<div class='alert alert-success'>An OTP has been sent to your email address.</div>";

    // Generate OTP input field
    echo "<input type='text' name='otp' placeholder='Enter OTP'>";

    // Submit button
    echo "<input type='submit' name='verify' value='Verify OTP'>";
}

if (isset($_POST['verify'])) {
    $enteredOTP = $_POST['otp'];
    $storedOTP = $_SESSION['otp'];

    if ($enteredOTP === $storedOTP) {
        // Redirect to voting.php
        header("Location: voting.php");
    } else {
        echo "<div class='alert alert-danger'>Invalid OTP. Please try again.</div>";
    }

    // Clear session
    unset($_SESSION['otp']);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting OTP</title>
</head>

<body>
    <h1>Voting OTP</h1>

    <form method="post">
        <input type="email" name="email" placeholder="Enter your email address">
        <input type="submit" name="submit" value="Continue">
    </form>
</body>

</html>