<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results of Votings</title>
    <!-- Include Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

    <?php
    // Include the database connection file
    require_once "database_res.php";

    // Function to generate a pie chart
    function drawPieChart($title, $data, $colors, $chartId)
    {
        echo "<div>";
        echo "<h3>$title</h3>";
        echo "<canvas id='$chartId' width='300' height='300'></canvas>";
        echo "</div>";
        echo "<script>";
        echo "var ctx_$chartId = document.getElementById('$chartId').getContext('2d');";
        echo "var data_$chartId = {";
        echo "labels: " . json_encode(array_keys($data)) . ",";
        echo "datasets: [{";
        echo "data: " . json_encode(array_values($data)) . ",";
        echo "backgroundColor: " . json_encode($colors);
        echo "}]}";

        echo "var myPieChart_$chartId = new Chart(ctx_$chartId, {";
        echo "type: 'pie',";
        echo "data: data_$chartId,";
        echo "options: { responsive: true, maintainAspectRatio: false }";
        echo "});";
        echo "</script>";
    }

    // Draw pie charts for Music
    $musicSecretaryData = [
        "Secretary" => getVoteCount("sec_music_vote")
    ];
    $musicDeputySecretaryData = [
        "Deputy Secretary" => getVoteCount("dep_music_vote")
    ];
    $musicChiefCoordinatorData = [
        "Chief Coordinator" => getVoteCount("chief_music_vote")
    ];
    $musicCoordinatorData = [
        "Coordinator" => getVoteCount("coord_music_vote")
    ];

    $musicColors = ["#FF6384", "#36A2EB", "#FFCE56", "#4CAF50"];

    drawPieChart("Secretary", $musicSecretaryData, $musicColors, "musicSecretaryChart");
    drawPieChart("Deputy Secretary", $musicDeputySecretaryData, $musicColors, "musicDeputySecretaryChart");
    drawPieChart("Chief Coordinator", $musicChiefCoordinatorData, $musicColors, "musicChiefCoordinatorChart");
    drawPieChart("Coordinator", $musicCoordinatorData, $musicColors, "musicCoordinatorChart");

    // Repeat the process for other categories (Dance, Literary, Logistics, Stage and Management, and Core Committee)

    // Function to get the total vote count for a category
    function getVoteCount($tableName)
    {
        global $conn;
        $sql = "SELECT COUNT(*) as count FROM $tableName";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['count'];
    }
    ?>

</body>

</html>