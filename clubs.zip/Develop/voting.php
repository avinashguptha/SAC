<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Page</title>
    <style>
        .nominee-container {
            display: flex;
            border: 1px solid #ccc;
            margin: 10px;
            padding: 10px;
            background-color: #f9f9f9;
        }

        .image-container {
            flex: 1;
        }

        .details-container {
            flex: 2;
            padding-left: 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        table {
            width: 100%;
        }

        th {
            text-align: left;
        }

        img {
            max-width: 100%;
            height: auto;
        }

        .position-container {
            margin-top: 20px;
        }

        .position-heading {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .vote-button {
            align-self: flex-end;
            background-color: #007bff;
            color: #fff;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
        }

        .background-image {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('Vfstr.jpg');
            background-size: cover;
            opacity: 0.15;
            pointer-events: none;
            z-index: -1;
        }

        .custom-heading {
            color: red;
            font-weight: bold;
            text-decoration: underline;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="background-image"></div>
    <h3 class="custom-heading">
        <center>BALLOT IS MORE POWERFUL THAN THE BULLET!</center>
    </h3>
    <p style="color: black; text-align: center;"><strong>Vote for Worthy to Select your Team</strong></p>

    <?php

    $positions = [
        "Secretary",
        "Deputy Secretary",
        "Chief Coordinator",
        "Coordinator",
        "President",
        "Vice President",
        "General Secretary",
        "Joint Secretary"
    ];

    require_once 'database_nom.php'; // Connection to the nomination database

    foreach ($positions as $position) {
        // Get nominees for the current position
        $queryNominees = "SELECT * FROM nomination WHERE cultural_post = '$position' OR core_post = '$position'";
        $resultNominees = mysqli_query($conn, $queryNominees);

        if (mysqli_num_rows($resultNominees) > 0) {
            // Display nominees for the current position
            echo '<div class="position-container">';
            echo '<div class="position-heading">' . $position . ' Candidates</div>';

            while ($rowNominee = mysqli_fetch_assoc($resultNominees)) {
                // Access the nominee's data
                $nomineeImage = $rowNominee['image_name'];
                $nomineeName = $rowNominee['name'];
                $nomineeRegdNo = $rowNominee['regd_no'];
                $nomineeDepartment = $rowNominee['department'];
                $nomineeYear = $rowNominee['year'];
                $nomineeSec = $rowNominee['sec'];
                $nomineePhone = $rowNominee['phone'];
                $nomineeMail = $rowNominee['mail'];
                $nomineePreviousContribution = $rowNominee['previous_contribution'];
                $nomineeRating = $rowNominee['rating'];
                $nomineeVerticle = $rowNominee['verticle'];
                $nomineeCorePost = $rowNominee['core_post'];
                $nomineeCulturalPost = $rowNominee['cultural_post'];

                // Display nominee details and vote button
                echo '<div class="nominee-container">';
                echo '<div class="image-container"><img src="' . $nomineeImage . '" alt="Nominee Image"></div>';

                echo '<div class="details-container">';
                echo '<table>';
                echo '<tr><th>Name:</th><td>' . $nomineeName . '</td></tr>';
                echo '<tr><th>Regd No:</th><td>' . $nomineeRegdNo . '</td></tr>';
                echo '<tr><th>Department:</th><td>' . $nomineeDepartment . '</td></tr>';
                echo '<tr><th>Year:</th><td>' . $nomineeYear . '</td></tr>';
                echo '<tr><th>Section:</th><td>' . $nomineeSec . '</td></tr>';
                echo '<tr><th>Verticle:</th><td>' . $nomineeVerticle . '</td></tr>';
                echo '<tr><th>Core Post:</th><td>' . $nomineeCorePost . '</td></tr>';
                echo '<tr><th>Cultural Post:</th><td>' . $nomineeCulturalPost . '</td></tr>';
                echo '</table>';

                // Add vote button with nominee data as data attribute
                echo '<button class="vote-button" data-nominee-data="' . json_encode([
                    "image_name" => $nomineeImage,
                    "name" => $nomineeName,
                    "regd_no" => $nomineeRegdNo,
                    "department" => $nomineeDepartment,
                    "year" => $nomineeYear,
                    "sec" => $nomineeSec,
                    "phone" => $nomineePhone,
                    "mail" => $nomineeMail,
                    "previous_contribution" => $nomineePreviousContribution,
                    "rating" => $nomineeRating,
                    "verticle" => $nomineeVerticle,
                    "core_post" => $nomineeCorePost,
                    "cultural_post" => $nomineeCulturalPost
                ]) . '">Vote</button>';

                echo '</div>'; // Closing details-container div
                echo '</div>'; // Closing nominee-container div

                // Add nominee details to the result database when the vote button is clicked
                if (isset($_POST['nomineeId']) && $_POST['nomineeId'] === $nomineeId) {
                    $nomineeData = $rowNominee;

                    $queryInsert = "INSERT INTO result (image_name, name, regd_no, department, year, sec, phone, mail, previous_contribution, rating, verticle, core_post, cultural_post) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $stmt = mysqli_prepare($connResults, $queryInsert);

                    mysqli_stmt_bind_param($stmt, "ssssssssssssssss", $nomineeData['image_name'], $nomineeData['name'], $nomineeData['regd_no'], $nomineeData['department'], $nomineeData['year'], $nomineeData['sec'], $nomineeData['phone'], $nomineeData['mail'], $nomineeData['previous_contribution'], $nomineeData['rating'], $nomineeData['verticle'], $nomineeData['core_post'], $nomineeData['cultural_post']);

                    mysqli_stmt_execute($stmt);

                    if (mysqli_affected_rows($connResults) > 0) {
                        echo '<p>Thank you for your vote!</p>';
                    } else {
                        echo '<p>Error adding vote.</p>';
                    }

                    mysqli_stmt_close($stmt);
                }
            }

            echo '</div>'; // Closing position-container div
        } else {
            if (mysqli_num_rows($resultNominees) === 0) {
                echo '<p>No nominees found for ' . $position . '.</p>';
            }
        }
    }

    // Close connections to both databases
    mysqli_close($conn);
    ?>
</body>

</html>