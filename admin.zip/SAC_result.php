<?php
// Require database connection
require_once "database_sac_result.php";

// Check for form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $insertSuccess = true;  // Flag to track insertion success

    foreach ($_POST as $key => $value) {
        if (strpos($key, "selected_name_") === 0) {
            $club = explode("_", $key)[2];
            $post = explode("_", $key)[3];
            $selectedName = $value;

            // Validate and sanitize data before insertion (add your validation logic here)

            $insertSql = "INSERT INTO sac_result (selected_name, club, post) VALUES ('$selectedName', '$club', '$post')";

            try {
                $conn->query($insertSql);
            } catch (Exception $e) {
                $insertSuccess = false;
                echo "Error: " . $e->getMessage();
                break;  // Exit loop on first failure
            }
        }
    }

    if ($conn->query($insertSql) === TRUE) {
        // Display JavaScript alert
        echo "<script>alert('All your votes have been submitted successfully!');</script>";

        // Redirect to index.html (JavaScript will handle it after alert)
        echo "<script>window.location.href = 'index.html';</script>";
        exit();
    } else {
        echo "Error: " . $insertSql . "<br>" . $conn->error;
    }
} else {
    echo "Error: No matching nominee found for $club $post.";
}
$conn->close();
