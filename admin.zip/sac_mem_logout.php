<?php
session_start();
session_destroy();
header("Location: sac_mem_login.php");
