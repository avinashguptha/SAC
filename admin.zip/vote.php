<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAC VOTING</title>
    <script src="https://kit.fontawesome.com/32e318ca72.js" crossorigin="anonymous"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .fa-solid.fa-circle-chevron-left {
            font-size: 40px;
            color: aqua;
            left: 10px;
        }

        .heading {
            text-align: center;
            font-size: 35px;
            color: #555;
        }

        .heading i {
            color: #1dceed;
            font-size: 15px;
        }

        /* Responsive table styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: aqua;
            text-align: center;
        }

        /* Adjust for smaller screens */
        @media (max-width: 768px) {
            h2 {
                font-size: 1.5rem;
                /* Reduce heading size on smaller screens */
            }

            p {
                font-size: 0.9rem;
                /* Reduce paragraph size on smaller screens */
            }

            /* Align headings and "No nominations" text to left */
            h2,
            p {
                text-align: left;
            }

            table {
                width: 100%;
            }

            th {
                display: block;
                text-align: left;
                /* Align text left on smaller screens */
            }
        }

        /* Centered submit button */
        .submit-button {
            display: block;
            margin: 0 auto;
        }

        /* Other styles (unchanged) */
        .background-image {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('images/Vfstr.jpg');
            background-size: cover;
            opacity: 0.15;
            pointer-events: none;
            z-index: -1;
        }

        input[type="submit"] {
            margin-top: 20px;
            padding: 10px;
            background-color: #4caf50;
            color: white;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="background-image"></div>
    <br>
    <div>
        <a href="sac_mem_logout.php"><i class="fa-solid fa-circle-chevron-left"></i></a>
    </div>
    <h1 class="heading"> <i class="fas fa-quote-left"></i> Vote Here <i class="fas fa-quote-right"></i> </h1>
    <form action="SAC_result.php" method="post">
        <?php
        // Require the database connection file
        require_once "database_sac_elections.php";

        // Array of clubs
        $clubs = array("Music", "Dance", "Literary", "TheatreArts", "Stage&Management", "Logistics", "PR&DM", "Photography&VideoEditing", "TechnicalDesign", "Core");

        foreach ($clubs as $club) {
            echo "<br><h2>$club Club</h2>";

            // Determine available posts based on club
            $availablePosts = ($club === "Core") ? array("president", "vice_president", "general_secretary", "joint_secretary") : array("secretary", "deputy", "chief");

            foreach ($availablePosts as $post) {
                // Modify query for Core Committee post titles
                $postQuery = str_replace("_", " ", ucfirst($post));

                $sql = "SELECT name FROM sac_nominate WHERE club = '$club' AND post = '$post'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    echo "<table>";
                    echo "<tr><th>$club $postQuery Nominee:</th></tr>";

                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td><label><input type='radio' name='selected_name_$club" . "_" . "$post' value='" . $row["name"] . "'>" . $row["name"] . "</label></td></tr>";
                    }

                    echo "</table>";
                } else {
                    echo "<p>No nominees for $club $postQuery Nominee.</p>";
                }
            }
        }

        // Add submit button
        echo "<input class='submit-button' type='submit' value='Submit Vote'><br>";

        // Close connection
        $conn->close();
        ?>
    </form>

</body>

</html>