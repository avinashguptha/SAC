<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WELCOME TO SAC FAMILY</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="background-image"></div>
    <div class="container_nom">
        <?php
        if (isset($_POST["submit"])) {
            $name = $_POST["name"];
            $regd_no = $_POST["regd_no"];
            $post = $_POST["post"];
            $club = $_POST["club"];
            $department = $_POST["department"];
            $year = $_POST["year"];

            $errors = array();

            if (empty($name) || empty($regd_no) || empty($post) || empty($club) || empty($department) || empty($year)) {
                array_push($errors, "All fields are required");
            }
            require_once "database_sac.php";

            $sql = "INSERT INTO sac_mem (name, regd_no, post, club, department, year) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_stmt_init($conn);

            if (mysqli_stmt_prepare($stmt, $sql)) {
                mysqli_stmt_bind_param($stmt, "sssssi", $name, $regd_no, $post, $club, $department, $year);
                mysqli_stmt_execute($stmt);
                echo "<div class='alert alert-success'>...WELCOME TO SAC FAMILY...</div>";
            } else {
                die("Something went wrong!!!");
            }
        }
        ?>

        <div class="nomination-form">
            <h5 class="custom-heading">
                <center>WELCOME TO SAC FAMILY</center>
            </h5>
            <p style="color: red; text-align: center;"><strong>(2024 - 2025)</strong></p>
            <form action="sac_mem.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
                <label for="regd no">Register Number:</label>
                <input type="text" id="regd no" name="regd_no" required>
                <label for="post">Post:</label>
                <select id="post" name="post" required>
                    <option>SELECT THE POST HERE!</option>
                    <option>Faculty</option>
                    <option>President</option>
                    <option>Vice President</option>
                    <option>General Secretary</option>
                    <option>Joint Secretary</option>
                    <option>Deans Nominee</option>
                    <option>Treasurer</option>
                    <option>Secretary</option>
                    <option>Deputy Secretary</option>
                    <option>Chief Coordinator</option>
                    <option>Coordinator</option>
                    <option>Volunteer</option>
                </select>
                <label for="club">Club:</label>
                <select id="club" name="club" required>
                    <option>SELECT THE CLUB HERE!</option>
                    <option>Core</option>
                    <option>Music</option>
                    <option>Dance</option>
                    <option>Literary</option>
                    <option>Theatre Arts</option>
                    <option>Stage and Management</option>
                    <option>Logistics</option>
                    <option>PR and DM</option>
                    <option>Fine Arts</option>
                    <option>Film Club</option>
                </select>
                <label for="dept">Department:</label>
                <select id="department" name="department" required>
                    <option>SELECT THE DEPARTMENT HERE!</option>
                    <option>Advanced Computer Science and Engineering</option>
                    <option>Agri. & Horti. Sciences</option>
                    <option>Applied Engineering</option>
                    <option>Biotechnology</option>
                    <option>Biomedical Engineering</option>
                    <option>Chemical Engineering</option>
                    <option>Civil Engineering</option>
                    <option>Computer Science and Engineering</option>
                    <option>Department of Chemistry</option>
                    <option>Department of Physics</option>
                    <option>Department of Mathematics</option>
                    <option>Department of English & Other Indian and Foreign Languages</option>
                    <option>Department of Social Sciences & Humanities</option>
                    <option>Diploma: ECE CSE</option>
                    <option>Electronics And Communication Engineering</option>
                    <option>Electrical And Electronics Engineering</option>
                    <option>Food Technology</option>
                    <option>Information Technology</option>
                    <option>Institute Of Law</option>
                    <option>Mechanical Engineering</option>
                    <option>Management Studies</option>
                    <option>Pharmaceutical Sciences</option>
                    <option>Robotic & Automation Engineering</option>
                    <option>Sciences & Humanities</option>
                    <option>Textile Technology</option>
                    <option>Distance & Online Education</option>
                    <option>Civil Services</option>
                </select>
                <label for="year">Year:</label>
                <input type="text" id="year" name="year" required>
                <br></br>
                <div class="form-btn">
                    <input type="submit" class="btn btn-primary" value="Register" name="submit">
                </div>
            </form>
        </div>
        <br><br><br>
        <div style="text-align: center;">
            <a href="admin_logout.php" class="btn btn-primary" role="button">Log Out</a>
        </div>
</body>

</html>