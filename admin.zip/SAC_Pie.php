<?php
// Connect to database (replace placeholders with your credentials)
$db = new mysqli('localhost', 'root', '', 'sac result');

// Prepare a statement to fetch data for all clubs and posts
$stmt = $db->prepare("SELECT selected_name, club, post FROM sac_result");
$stmt->execute();
$result = $stmt->get_result();

// Store data in a structured array
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[$row['club']][$row['post']][] = $row['selected_name'];
}

// Close database connection
$db->close();

// Begin HTML output
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAC Result Tables</title>
    <script src="https://kit.fontawesome.com/32e318ca72.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
</head>
<style>
    .background-image {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('images/Vfstr.jpg');
        background-size: cover;
        opacity: 0.15;
        pointer-events: none;
        z-index: -1;
    }

    body {
        font-family: Arial, sans-serif;
    }

    .fa-solid.fa-circle-arrow-left {
        color: #1dceed;
        font-size: 40px;
    }

    .heading {
        text-align: center;
        font-size: 30px;
        color: #555;
    }

    .heading i {
        color: #1dceed;
        font-size: 15px;
    }


    /* Responsive table styles */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th,
    td {
        width: 50%;
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: aqua;
        text-align: center;
    }

    @media (max-width: 575px) {
        table {
            width: 100%;
            font-size: 0.8rem;
            /* Reduce font size */
        }

        th {
            width: 50%;
            padding: 5px;
            /* Reduce padding */
        }
    }

    /* Adjust for smaller screens */
    @media (max-width: 768px) {
        table {
            width: 100%;
            overflow-x: auto;
        }

        th {
            width: 50%;
            text-align: left;
            /* Align text left on smaller screens */
        }
    }

    /* Centered submit button */
    .submit-button {
        display: block;
        margin: 0 auto;
    }

    /* Other styles (unchanged) */
    .background-image {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('images/Vfstr.jpg');
        background-size: cover;
        opacity: 0.15;
        pointer-events: none;
        z-index: -1;
    }

    input[type="submit"] {
        margin-top: 20px;
        padding: 10px;
        background-color: #4caf50;
        color: white;
        cursor: pointer;
    }
</style>

<body>
    <div class="background-image"></div>
    <br><br>
    <div style="text-align: left;">
        <a href="index.html"><i class="fa-solid fa-circle-arrow-left"></a></i>
    </div>
    <h1 class="heading"> <i class="fas fa-quote-left"></i> Results Are Out! <i class="fas fa-quote-right"></i> </h1>

    <?php
    // Iterate through each club
    foreach ($data as $club => $positions) {
        echo "<br><center><h3>$club</h3></center>";

        // Iterate through each post within the club
        foreach ($positions as $post => $names) {
            echo "<table>";
            echo "<thead><tr><th>$post</th><th>Votes</th></tr></thead>";
            echo "<tbody>";

            $nameCounts = array_count_values($names);
            foreach ($nameCounts as $name => $votes) {
                echo "<tr>";
                echo "<td>$name</td>";
                echo "<td>$votes</td>";
                echo "</tr>";
            }

            echo "</tbody>";
            echo "</table>";
        }
    }
    ?>
</body>

</html>